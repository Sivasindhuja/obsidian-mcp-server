```markdown
# MCP Obsidian Server

An [Model Context Protocol (MCP)](https://modelcontextprotocol.io/) server that allows LLMs to interact with your Obsidian vault via the [Local REST API](https://github.com/codemirror/obsidian-local-rest-api).

This server enables AI agents (like Claude Desktop) to read, write, search, and analyze your personal knowledge base with built-in stability features like circuit breakers and exponential backoff.

## 🚀 Features

*   **Full File Management**: List, read, create, append, and patch notes.
*   **Powerful Search**: Supports both simple text queries and complex JSON-logic searches.
*   **Vault Analytics**: Tools to calculate link density, identify orphaned notes, and track top tags.
*   **Resilience**: 
    *   **Retry Logic**: Exponential backoff with jitter for transient network errors.
    *   **Circuit Breaker**: Automatically pauses requests if the Obsidian API becomes unreachable to prevent resource exhaustion.
*   **Periodic Notes**: Deep integration for Daily, Weekly, and Monthly notes.

## 📋 Prerequisites

1.  **Obsidian** must be open with the vault you wish to access.
2.  **Local REST API Plugin**:
    *   Install it via Obsidian Community Plugins.
    *   Enable the plugin and toggle "Enable Northbound" if required.
    *   Copy your **API Key** from the plugin settings.
    *   Note your port (default is `27124`).

## 🛠 Installation

### Via Smithery

The easiest way to install this for Claude Desktop is via [Smithery](https://smithery.ai/server/mcp-obsidian):
```bash
npx @smithery/cli install mcp-obsidian --config '{"OBSIDIAN_API_KEY":"your_api_key_here"}'
```

### Manual Installation (Development)

1. **Clone and Install**:
   ```bash
   git clone [https://github.com/Sivasindhuja/mcp-server.git](https://github.com/Sivasindhuja/mcp-server.git)
   cd mcp-obsidian
   pip install .
   ```

2. **Environment Setup**:
   Create a `.env` file in the root directory:
   ```env
   OBSIDIAN_API_KEY=your_api_key_here
   OBSIDIAN_HOST=127.0.0.1
   OBSIDIAN_PORT=27124
   OBSIDIAN_PROTOCOL=https
   ```

## 🔌 Configuration for Claude Desktop

Add this to your `claude_desktop_config.json`:
```json
{
  "mcpServers": {
    "obsidian": {
      "command": "mcp-obsidian",
      "env": {
        "OBSIDIAN_API_KEY": "your_api_key_here",
        "OBSIDIAN_HOST": "127.0.0.1"
      }
    }
  }
}
```

## 🧰 Available Tools

| Tool | Description |
| :--- | :--- |
| `list_files_in_vault` | Returns a list of all files in your vault. |
| `get_file_contents` | Fetches the full text content of a specific note. |
| `simple_search` | Searches the vault for a specific string. |
| `create_note` | Creates a new note with specified content. |
| `get_vault_stats` | Provides statistics on links, tags, and orphaned files. |
| `append_content` | Adds text to the end of an existing note. |
| `check_connection` | Diagnostic tool to verify the connection to Obsidian. |

## 🛡️ Safety & Reliability

This server implements a **Circuit Breaker** pattern. If the connection to Obsidian fails 3 times consecutively, the circuit opens for 10 seconds, immediately rejecting further calls to allow the service to recover. This prevents the LLM from getting stuck in a loop of failed requests.

## 📝 License

MIT - Developed by **Siva Sindhuja**
```